// Creating Object 1
let student1 = {
    name: "ABC",
    age: 20,
    course: "B.Tech",
    marks: 85
};


// Creating Object 2
let student2 = {
    name: "DEF",
    age: 21,
    course: "BCA",
    marks: 91
};


// Creating Object 3
let student3 = {
    name: "GHI",
    age: 20,
    course: "B.Tech",
    marks: 78
};


// Accessing Object Properties
console.log(student1.name);
console.log(student1.course);


// Updating Property
student1.marks = 88;


// Adding New Property
student1.email = "aarav@example.com";


// Removing Property
delete student1.age;


// Creating Array of Objects
let students = [
    student1,
    student2,
    student3
];


// Display Objects
let output = "";

students.forEach(function(student) {

    output += `
        <div class="object-card">

            <h2>${student.name}</h2>

            <p>
                <strong>Course:</strong>
                ${student.course}
            </p>

            <p>
                <strong>Marks:</strong>
                ${student.marks}
            </p>

            <p>
                <strong>Age:</strong>
                ${student.age ?? "Property Removed"}
            </p>

            ${
                student.email
                ? `<p><strong>Email:</strong> ${student.email}</p>`
                : ""
            }

        </div>
    `;
});


// Display on Webpage
document.getElementById("output").innerHTML = `
    <h2>Student Records</h2>

    <p>
        <strong>Updated Marks of Aarav:</strong>
        ${student1.marks}
    </p>

    <p>
        <strong>New Email Property:</strong>
        ${student1.email}
    </p>

    <p>
        <strong>Removed Age:</strong>
        ${student1.age ?? "Removed"}
    </p>

    ${output}
`;