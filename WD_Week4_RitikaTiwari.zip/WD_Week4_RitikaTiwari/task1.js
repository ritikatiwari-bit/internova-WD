// Function Declaration
function calculateTotalMarks(marks1, marks2, marks3) {
    return marks1 + marks2 + marks3;
}

// Function with Parameters and Return Value
function calculatePercentage(total, subjects) {
    return (total / (subjects * 100)) * 100;
}

// Another Function
function getResult(percentage) {
    if (percentage >= 40) {
        return "Pass";
    } else {
        return "Fail";
    }
}

// Arrow Function
const generateGreeting = (name) => {
    return `Hello, ${name}! Welcome to JavaScript.`;
};


// Function Arguments
let studentName = "Ritika";

let math = 82;
let science = 76;
let computer = 91;

// Calling functions
let total = calculateTotalMarks(math, science, computer);

let percentage = calculatePercentage(total, 3);

let result = getResult(percentage);

let greeting = generateGreeting(studentName);


// Displaying result using DOM
document.getElementById("output").innerHTML = `
    <h2>${greeting}</h2>

    <p><strong>Math Marks:</strong> ${math}</p>
    <p><strong>Science Marks:</strong> ${science}</p>
    <p><strong>Computer Marks:</strong> ${computer}</p>

    <p><strong>Total Marks:</strong> ${total}</p>

    <p><strong>Percentage:</strong> 
        ${percentage.toFixed(2)}%
    </p>

    <p><strong>Result:</strong> ${result}</p>
`;