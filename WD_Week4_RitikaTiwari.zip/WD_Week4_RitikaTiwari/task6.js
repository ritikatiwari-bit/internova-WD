// Array containing student objects

let students = [

    {
        id: 1,
        name: "ABC",
        course: "B.Tech",
        marks: 86
    },

    {
        id: 2,
        name: "DEF",
        course: "BCA",
        marks: 92
    },

    {
        id: 3,
        name: "GHI",
        course: "B.Tech",
        marks: 78
    }

];


// Selecting Elements

const form =
    document.getElementById("studentForm");

const studentList =
    document.getElementById("studentList");

const searchInput =
    document.getElementById("searchInput");

const message =
    document.getElementById("message");


// Function to Calculate Grade

function getGrade(marks) {

    if (marks >= 90) {
        return "A+";
    }

    if (marks >= 80) {
        return "A";
    }

    if (marks >= 70) {
        return "B";
    }

    if (marks >= 60) {
        return "C";
    }

    return "D";
}


// Function to Display Students

function renderStudents(list = students) {

    studentList.innerHTML = "";


    if (list.length === 0) {

        studentList.innerHTML =
            "<p>No student records found.</p>";

        return;
    }


    list.forEach(function(student) {

        const card =
            document.createElement("article");

        card.className = "student-card";


        card.innerHTML = `

            <h3>
                ${student.name}
            </h3>

            <p>
                <strong>Course:</strong>
                ${student.course}
            </p>

            <p>
                <strong>Marks:</strong>
                ${student.marks}
            </p>

            <p>
                <strong>Grade:</strong>
                ${getGrade(student.marks)}
            </p>

            <button
                class="delete-btn"
                data-id="${student.id}">
                Delete
            </button>

        `;


        studentList.appendChild(card);

    });

}


// SUBMIT EVENT

form.addEventListener("submit", function(event) {

    event.preventDefault();


    const name =
        document.getElementById("studentName")
            .value.trim();

    const course =
        document.getElementById("studentCourse")
            .value.trim();

    const marks =
        Number(
            document.getElementById("studentMarks")
                .value
        );


    // Validation

    if (
        name === "" ||
        course === "" ||
        Number.isNaN(marks) ||
        marks < 0 ||
        marks > 100
    ) {

        message.textContent =
            "Please enter valid student details.";

        return;
    }


    // Creating a new object

    const newStudent = {

        id: Date.now(),

        name: name,

        course: course,

        marks: marks

    };


    // Adding object to array

    students.push(newStudent);


    // Reset form

    form.reset();


    message.textContent =
        `${name} was added successfully.`;


    // Update webpage

    renderStudents();

});


// SEARCH / INPUT EVENT

searchInput.addEventListener("input", function() {

    const query =
        searchInput.value
            .toLowerCase()
            .trim();


    const filteredStudents =
        students.filter(function(student) {

            return student.name
                .toLowerCase()
                .includes(query);

        });


    renderStudents(filteredStudents);

});


// DELETE EVENT

studentList.addEventListener("click", function(event) {

    if (
        !event.target.classList
            .contains("delete-btn")
    ) {
        return;
    }


    const id =
        Number(event.target.dataset.id);


    // Removing student from array

    students =
        students.filter(function(student) {

            return student.id !== id;

        });


    message.textContent =
        "Student record removed.";


    // Update webpage

    renderStudents();

});


// Initial Display

renderStudents();