// CLICK EVENT

const clickBtn =
    document.getElementById("clickBtn");

const clickOutput =
    document.getElementById("clickOutput");


clickBtn.addEventListener("click", function() {

    clickOutput.textContent =
        "The click event was triggered!";

});


// INPUT EVENT

const nameInput =
    document.getElementById("nameInput");


nameInput.addEventListener("input", function() {

    if (nameInput.value === "") {

        document.getElementById("inputOutput")
            .textContent = "";

    } else {

        document.getElementById("inputOutput")
            .textContent =
            `Hello, ${nameInput.value}!`;

    }

});


// CHANGE EVENT

const courseSelect =
    document.getElementById("courseSelect");


courseSelect.addEventListener("change", function() {

    document.getElementById("changeOutput")
        .textContent =
        `You selected: ${courseSelect.value}`;

});


// SUBMIT EVENT

const eventForm =
    document.getElementById("eventForm");


eventForm.addEventListener("submit", function(event) {

    event.preventDefault();

    const email =
        document.getElementById("emailInput").value;

    document.getElementById("submitOutput")
        .textContent =
        `Form submitted successfully for ${email}`;

});


// MOUSE EVENTS

const mouseArea =
    document.getElementById("mouseArea");

const eventOutput =
    document.getElementById("eventOutput");


mouseArea.addEventListener("mouseenter", function() {

    eventOutput.textContent =
        "Mouse entered the area.";

});


mouseArea.addEventListener("mouseleave", function() {

    eventOutput.textContent =
        "Mouse left the area.";

});


// KEYBOARD EVENT

document.addEventListener("keydown", function(event) {

    eventOutput.textContent =
        `You pressed: "${event.key}"`;

});