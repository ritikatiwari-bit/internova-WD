// Creating an Array
let students = [
    "ABC",
    "DEF",
    "GHI",
    "JKL",
    "MNO"
];


// Accessing Array Element
let firstStudent = students[0];


// Adding an Element
students.push("XYZ");


// Removing an Element
let removedStudent = students.pop();


// Updating an Element
students[1] = "OPQ";


// Array Length
let totalStudents = students.length;


// Checking if an element exists
let hasRohan = students.includes("GHI");


// Sorting Array
let sortedStudents = [...students].sort();


// Iterating through Array
let studentList = "";

students.forEach(function(student, index) {
    studentList += `
        <li>
            ${index + 1}. ${student}
        </li>
    `;
});


// Displaying Output
document.getElementById("output").innerHTML = `
    <h2>Student Array Demonstration</h2>

    <p>
        <strong>First Student:</strong>
        ${firstStudent}
    </p>

    <p>
        <strong>Removed Student:</strong>
        ${removedStudent}
    </p>

    <p>
        <strong>Total Students:</strong>
        ${totalStudents}
    </p>

    <p>
        <strong>Contains Rohan:</strong>
        ${hasRohan}
    </p>

    <p>
        <strong>Sorted Students:</strong>
        ${sortedStudents.join(", ")}
    </p>

    <h3>Current Student Array</h3>

    <ul>
        ${studentList}
    </ul>
`;