// Selecting HTML Elements
const title = document.getElementById("title");

const description =
    document.getElementById("description");

const dynamicArea =
    document.getElementById("dynamicArea");


// Changing Text Content
document.getElementById("textBtn")
    .addEventListener("click", function() {

        description.textContent =
            "The text content was changed using JavaScript.";

    });


// Changing HTML Content
document.getElementById("htmlBtn")
    .addEventListener("click", function() {

        description.innerHTML =
            "<strong>HTML content was changed dynamically!</strong>";

    });


// Changing CSS Styles
document.getElementById("styleBtn")
    .addEventListener("click", function() {

        title.style.fontSize = "42px";

        title.style.letterSpacing = "2px";

        description.style.padding = "15px";

    });


// Adding Elements
document.getElementById("addBtn")
    .addEventListener("click", function() {

        const newElement =
            document.createElement("p");

        newElement.className = "item";

        newElement.textContent =
            "New element added using JavaScript.";

        dynamicArea.appendChild(newElement);

    });


// Removing Elements
document.getElementById("removeBtn")
    .addEventListener("click", function() {

        const items =
            dynamicArea.querySelectorAll(".item");

        if (items.length > 0) {

            items[items.length - 1].remove();

        }

    });