// ============================================
console.log("TASK 2: VARIABLES AND DATA TYPES");
// ============================================

// Variable declaration using let
let studentName;

// Variable assignment
studentName = "Ritika";

// Variable declaration and assignment
let agenow = 21;

// Constant declaration
const collegeName = "kipm College";

// Different JavaScript data types

// String
let course = "Computer Science";

// Number
let marksnow = 85;

// Boolean
let isStudent = true;

// Undefined
let futurePlan;

// Null
let middleName = null;

// Display values
console.log("Student Name:", studentName);
console.log("Age:", agenow);
console.log("College:", collegeName);
console.log("Course:", course);
console.log("Marks:", marksnow);
console.log("Is Student:", isStudent);
console.log("Future Plan:", futurePlan);
console.log("Middle Name:", middleName);

// Checking data types using typeof

console.log("Type of studentName:", typeof studentName);
console.log("Type of age:", typeof agenow);
console.log("Type of collegeName:", typeof collegeName);
console.log("Type of course:", typeof course);
console.log("Type of marks:", typeof marksnow);
console.log("Type of isStudent:", typeof isStudent);
console.log("Type of futurePlan:", typeof futurePlan);
console.log("Type of middleName:", typeof middleName);