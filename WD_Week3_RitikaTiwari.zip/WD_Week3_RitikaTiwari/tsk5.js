// ============================================
console.log("TASK 5: LOOPS");
// ============================================

// --------------------------------------------
console.log("1. for loop");
// --------------------------------------------

console.log("Numbers from 1 to 10:");

for (let i = 1; i <= 10; i++) {
    console.log(i);
}

// --------------------------------------------
//2. for loop - Print even numbers
// --------------------------------------------

console.log("\nEven Numbers from 1 to 20:");

for (let i = 1; i <= 20; i++) {

    if (i % 2 === 0) {
        console.log(i);
    }
}

// --------------------------------------------
//3. for loop - Print odd numbers
// --------------------------------------------

console.log("\nOdd Numbers from 1 to 20:");

for (let i = 1; i <= 20; i++) {

    if (i % 2 !== 0) {
        console.log(i);
    }
}

// --------------------------------------------
console.log("4. Multiplication table");
// --------------------------------------------

let tableNumber = 5;

console.log("\nMultiplication Table of", tableNumber);

for (let i = 1; i <= 10; i++) {
    console.log(tableNumber + " x " + i + " = " + (tableNumber * i));
}

// --------------------------------------------
//5. Find the sum of numbers from 1 to 10
// --------------------------------------------

let sum = 0;

for (let i = 1; i <= 10; i++) {
    sum += i;
}

console.log("\nSum of numbers from 1 to 10:", sum);

// --------------------------------------------
console.log("6. Print numbers in reverse order");
// --------------------------------------------

console.log("\nNumbers from 10 to 1:");

for (let i = 10; i >= 1; i--) {
    console.log(i);
}

// --------------------------------------------
console.log("7. while loop");
// --------------------------------------------


let count = 1;

while (count <= 5) {
    console.log(count);
    count++;
}

// --------------------------------------------
console.log("8. do...while loop");
// --------------------------------------------


let number = 1;

do {
    console.log(number);
    number++;
} while (number <= 5);

// --------------------------------------------
console.log("9. Loop with condition");
// --------------------------------------------

console.log("\nNumbers divisible by 3:");

let value = 1;

while (value <= 20) {

    if (value % 3 === 0) {
        console.log(value);
    }

    value++;
}

// --------------------------------------------
console.log("10. Decrement in loop");
// --------------------------------------------

console.log("\nCountdown:");

let countdown = 5;

while (countdown >= 1) {
    console.log(countdown);
    countdown--;
}

console.log("Countdown complete!");