// ============================================
console.log("TASK 3: OPERATORS");
// ============================================

// --------------------------------------------
// 1. Arithmetic Operators
// --------------------------------------------

let number1 = 20;
let number2 = 5;

console.log("Arithmetic Operators:");

console.log("Addition:", number1 + number2);
console.log("Subtraction:", number1 - number2);
console.log("Multiplication:", number1 * number2);
console.log("Division:", number1 / number2);
console.log("Modulus:", number1 % number2);
console.log("Exponentiation:", number1 ** number2);

// --------------------------------------------
// 2. Assignment Operators
// --------------------------------------------

let score = 10;

console.log("\nAssignment Operators:");

score += 5;
console.log("After += 5:", score);

score -= 2;
console.log("After -= 2:", score);

score *= 2;
console.log("After *= 2:", score);

score /= 2;
console.log("After /= 2:", score);

// --------------------------------------------
// 3. Comparison Operators
// --------------------------------------------

let a = 10;
let b = 20;

console.log("\nComparison Operators:");

console.log("a == b:", a == b);
console.log("a === b:", a === b);
console.log("a != b:", a != b);
console.log("a !== b:", a !== b);
console.log("a > b:", a > b);
console.log("a < b:", a < b);
console.log("a >= b:", a >= b);
console.log("a <= b:", a <= b);

// --------------------------------------------
// 4. Logical Operators
// --------------------------------------------

let hasID = true;
let hasTicket = true;

console.log("\nLogical Operators:");

console.log("AND (&&):", hasID && hasTicket);
console.log("OR (||):", hasID || hasTicket);
console.log("NOT (!):", !hasID);

// --------------------------------------------
// 5. Increment Operator
// --------------------------------------------

let count = 5;

console.log("\nIncrement Operator:");

console.log("Original count:", count);

count++;
console.log("After increment:", count);

// --------------------------------------------
// 6. Decrement Operator
// --------------------------------------------

console.log("\nDecrement Operator:");

count--;
console.log("After decrement:", count);