// ============================================
console.log("TASK 6: JAVASCRIPT PRACTICE PROGRAMS");
// ============================================


// ============================================
console.log("PROGRAM 1: Check whether a number is prime");
// ============================================

let primeNumber = 29;
let isPrime = true;

if (primeNumber <= 1) {
    isPrime = false;
} else {

    for (let i = 2; i < primeNumber; i++) {

        if (primeNumber % i === 0) {
            isPrime = false;
            break;
        }
    }
}


if (isPrime) {
    console.log(primeNumber + " is a prime number.");
} else {
    console.log(primeNumber + " is not a prime number.");
}


// ============================================
//PROGRAM 2: Calculate factorial
// ============================================

let factorialNumber = 5;
let factorial = 1;

for (let i = 1; i <= factorialNumber; i++) {
    factorial *= i;
}

console.log("\nProgram 2: Factorial");
console.log("Factorial of " + factorialNumber + " is " + factorial);


// ============================================
//PROGRAM 3: Find the largest number
// ============================================

let value1 = 25;
let value2 = 70;
let value3 = 45;

let largest;

if (value1 >= value2 && value1 >= value3) {
    largest = value1;
} else if (value2 >= value1 && value2 >= value3) {
    largest = value2;
} else {
    largest = value3;
}

console.log("\nProgram 3: Largest Number");
console.log("Largest number is:", largest);


// ============================================
//PROGRAM 4: Calculate student result
// ============================================

let studentMarks = 76;

console.log("\nProgram 4: Student Result");

if (studentMarks >= 40) {

    console.log("Result: PASS");

    if (studentMarks >= 75) {
        console.log("Performance: Distinction");
    } else if (studentMarks >= 60) {
        console.log("Performance: First Division");
    } else {
        console.log("Performance: Second Division");
    }

} else {
    console.log("Result: FAIL");
}


// ============================================
//PROGRAM 5: Find the sum of even numbers
// ============================================

let evenSum = 0;

for (let i = 1; i <= 20; i++) {

    if (i % 2 === 0) {
        evenSum += i;
    }
}

console.log("\nProgram 5: Sum of Even Numbers");
console.log("Sum of even numbers from 1 to 20:", evenSum);


// ============================================
//PROGRAM 6: Multiplication table
// ============================================

let multiplicationNumber = 7;

console.log("\nProgram 6: Multiplication Table");

for (let i = 1; i <= 10; i++) {

    let result = multiplicationNumber * i;

    console.log(
        multiplicationNumber + " x " + i + " = " + result
    );
}


// ============================================
//PROGRAM 7: Count positive and negative numbers
// ============================================

let numbers = [10, -5, 20, -8, 15, -2, 0];

let positiveCount = 0;
let negativeCount = 0;
let zeroCount = 0;

for (let i = 0; i < numbers.length; i++) {

    if (numbers[i] > 0) {
        positiveCount++;
    } else if (numbers[i] < 0) {
        negativeCount++;
    } else {
        zeroCount++;
    }
}

console.log("\nProgram 7: Count Numbers");

console.log("Positive numbers:", positiveCount);
console.log("Negative numbers:", negativeCount);
console.log("Zeroes:", zeroCount);