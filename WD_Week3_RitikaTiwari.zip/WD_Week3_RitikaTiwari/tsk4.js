// ============================================
console.log("TASK 4: CONDITIONAL STATEMENTS");
// ============================================

// --------------------------------------------
//1. Check whether a number is positive,negative, or zero
// --------------------------------------------

let number = -10;

console.log("Checking Positive, Negative or Zero:");

if (number > 0) {
    console.log("The number is positive.");
} else if (number < 0) {
    console.log("The number is negative.");
} else {
    console.log("The number is zero.");
}

// --------------------------------------------
//2. Check whether a number is even or odd
// --------------------------------------------

let checkNumber = 17;

console.log("\nChecking Even or Odd:");

if (checkNumber % 2 === 0) {
    console.log(checkNumber + " is even.");
} else {
    console.log(checkNumber + " is odd.");
}

// --------------------------------------------
//3. Check age eligibility
// --------------------------------------------

let age = 20;

console.log("\nChecking Age Eligibility:");

if (age >= 18) {
    console.log("The person is eligible to vote.");
} else {
    console.log("The person is not eligible to vote.");
}

// --------------------------------------------
//4. Find the greater of two numbers
// --------------------------------------------

let firstNumber = 45;
let secondNumber = 30;

console.log("\nFinding Greater Number:");

if (firstNumber > secondNumber) {
    console.log(firstNumber + " is greater.");
} else if (secondNumber > firstNumber) {
    console.log(secondNumber + " is greater.");
} else {
    console.log("Both numbers are equal.");
}

// --------------------------------------------
//5. Find the greatest of three numbers
// --------------------------------------------

let numberA = 50;
let numberB = 75;
let numberC = 60;

console.log("\nFinding Greatest of Three Numbers:");

if (numberA >= numberB && numberA >= numberC) {
    console.log(numberA + " is the greatest.");
} else if (numberB >= numberA && numberB >= numberC) {
    console.log(numberB + " is the greatest.");
} else {
    console.log(numberC + " is the greatest.");
}

// --------------------------------------------
//6. Assign grades based on marks
// --------------------------------------------

let marks = 82;

console.log("\nGrade Assignment:");

if (marks >= 90) {
    console.log("Grade: A+");
} else if (marks >= 80) {
    console.log("Grade: A");
} else if (marks >= 70) {
    console.log("Grade: B");
} else if (marks >= 60) {
    console.log("Grade: C");
} else if (marks >= 50) {
    console.log("Grade: D");
} else {
    console.log("Grade: F");
}

// --------------------------------------------
//7. Nested if statement
// --------------------------------------------

let studentAge = 20;
let hasIdentityCard = true;

console.log("\nNested If Example:");

if (studentAge >= 18) {

    console.log("Student is an adult.");

    if (hasIdentityCard) {
        console.log("Student has a valid identity card.");
    } else {
        console.log("Student does not have an identity card.");
    }

} else {
    console.log("Student is a minor.");
}

// --------------------------------------------
//8. Logical conditions
// --------------------------------------------

let userAge = 22;
let hasAdmission = true;

console.log("\nLogical Condition Example:");

if (userAge >= 18 && hasAdmission) {
    console.log("Student can enter the college program.");
} else {
    console.log("Student cannot enter the college program.");
}