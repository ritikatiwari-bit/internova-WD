// ============================================
// TASK 1: JAVASCRIPT BASICS
// ============================================

// Single-line comment
// This program demonstrates basic JavaScript syntax.

// console.log() is used to display output in the console.
console.log("Hello, JavaScript!");
console.log("Welcome to Week 3 JavaScript Assignment.");

console.log("Basics of JS include variables, data types, operators, and control structures.");

/*
    This is a multi-line comment.
    It can be used to explain multiple
    lines of code.
*/

console.log("Single line comments start with //");
console.log("Multi-line comments start with /* and end with */ for multi-line comments.");

// Basic JavaScript statements
let studentName = "Ritika";
let course = "Computer Science";
let year = 3;

// Displaying values using console.log()
console.log("Student Name:", studentName);
console.log("Course:", course);
console.log("Year:", year);

// Basic calculation
let number1 = 10;
let number2 = 20;
let sum = number1 + number2;

console.log("First Number:", number1);
console.log("Second Number:", number2);
console.log("Sum:", sum);

// JavaScript statement using a string
console.log("JavaScript is easy to learn with practice.");