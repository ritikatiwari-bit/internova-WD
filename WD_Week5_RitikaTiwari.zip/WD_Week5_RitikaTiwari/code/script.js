// ==========================================
// SCRIPT.JS
// MAIN CONTROLLER
// ==========================================


// ===============================
// INITIAL DISPLAY
// ===============================

displayTasks(tasks);

updateDashboardData();

// ===============================
// ADD TASK EVENT
// ===============================

taskForm.addEventListener(
    "submit",
    function (event) {
        event.preventDefault();

        // Get data from form

        const taskData =
            getFormData();


        // Validation

        if (
            taskData.title === "" ||
            taskData.description === "" ||
            taskData.priority === "" ||
            taskData.category === "" ||
            taskData.date === ""
        ) {

            alert(
                "Please fill in all fields."
            );

            return;
        }

        // Add task

        addTask(taskData);

        // Clear form

        clearForm();
    }
);

// ===============================
// SEARCH EVENT
// ===============================

searchInput.addEventListener(
    "input",
    filterTasks
);

// ===============================
// STATUS FILTER EVENT
// ===============================

filterStatus.addEventListener(
    "change",
    filterTasks
);


// ===============================
// PRIORITY FILTER EVENT
// ===============================

filterPriority.addEventListener(
    "change",
    filterTasks
);

// ===============================
// TASK BUTTON EVENTS
// ===============================

taskContainer.addEventListener(
    "click",
    function (event) {
        const id =
            Number(
                event.target.dataset.id
            );

        // Complete / Undo

        if (
            event.target.classList.contains(
                "complete-btn"
            )
        ) {
            toggleTaskStatus(id);
        }

        // Edit
        if (
            event.target.classList.contains(
                "edit-btn"
            )
        ) {
            editTask(id);
        }

        // Delete

        if (
            event.target.classList.contains(
                "delete-btn"
            )
        ) {
            deleteTask(id);
        }

    }
);