// ==========================================
// FEATURE.JS
// TASK MANAGEMENT FEATURES
// ==========================================


// ===============================
// TASK ARRAY
// ===============================

let tasks = [

    {
        id: 1,
        title: "Complete JavaScript Assignment",
        description:
            "Finish the Task Management Application.",
        priority: "High",
        category: "Study",
        date: "2026-09-05",
        status: "Pending"
    },

    {
        id: 2,
        title: "Prepare Project Presentation",
        description:
            "Create slides for the project presentation.",
        priority: "Medium",
        category: "Study",
        date: "2026-09-07",
        status: "Pending"
    },

    {
        id: 3,
        title: "Team Meeting",
        description:
            "Attend the weekly project meeting.",
        priority: "Low",
        category: "Work",
        date: "2026-09-04",
        status: "Completed"
    }

];


// ===============================
// ADD TASK
// ===============================

function addTask(taskData) {

    const newTask = {

        id: Date.now(),

        title: taskData.title,

        description: taskData.description,

        priority: taskData.priority,

        category: taskData.category,

        date: taskData.date,

        status: "Pending"
    };


    tasks.push(newTask);


    displayTasks(tasks);


    updateDashboardData();
}


// ===============================
// DELETE TASK
// ===============================

function deleteTask(id) {

    tasks =
        tasks.filter(task => task.id !== id);


    displayTasks(tasks);


    updateDashboardData();
}


// ===============================
// EDIT TASK
// ===============================

function editTask(id) {

    const task =
        tasks.find(task => task.id === id);


    if (!task) {

        return;
    }


    const newTitle =
        prompt(
            "Enter new task title:",
            task.title
        );


    if (
        newTitle !== null &&
        newTitle.trim() !== ""
    ) {

        task.title =
            newTitle.trim();


        displayTasks(tasks);
    }
}


// ===============================
// COMPLETE / UNDO TASK
// ===============================

function toggleTaskStatus(id) {

    const task =
        tasks.find(task => task.id === id);


    if (!task) {

        return;
    }


    if (task.status === "Pending") {

        task.status = "Completed";

    } else {

        task.status = "Pending";
    }


    displayTasks(tasks);


    updateDashboardData();
}


// ===============================
// SEARCH AND FILTER
// ===============================

function filterTasks() {

    const searchText =
        searchInput.value.toLowerCase();


    const selectedStatus =
        filterStatus.value;


    const selectedPriority =
        filterPriority.value;


    const filteredTasks =
        tasks.filter(task => {


            const matchesSearch =
                task.title
                    .toLowerCase()
                    .includes(searchText);


            const matchesStatus =
                selectedStatus === "" ||
                task.status === selectedStatus;


            const matchesPriority =
                selectedPriority === "" ||
                task.priority === selectedPriority;


            return (
                matchesSearch &&
                matchesStatus &&
                matchesPriority
            );

        });


    displayTasks(filteredTasks);
}


// ===============================
// DASHBOARD DATA
// ===============================

function updateDashboardData() {

    const total =
        tasks.length;


    const completed =
        tasks.filter(
            task => task.status === "Completed"
        ).length;


    const pending =
        tasks.filter(
            task => task.status === "Pending"
        ).length;


    const highPriority =
        tasks.filter(
            task => task.priority === "High"
        ).length;


    updateDashboard(
        total,
        completed,
        pending,
        highPriority
    );
}