// ==========================================
// DOM.JS
// DOM ELEMENTS AND DOM MANIPULATION
// ==========================================


// ===============================
// SELECT DOM ELEMENTS
// ===============================

const taskForm =
    document.getElementById("taskForm");

const taskTitle =
    document.getElementById("taskTitle");

const taskDescription =
    document.getElementById("taskDescription");

const taskPriority =
    document.getElementById("taskPriority");

const taskCategory =
    document.getElementById("taskCategory");

const taskDate =
    document.getElementById("taskDate");

const taskContainer =
    document.getElementById("taskContainer");

const searchInput =
    document.getElementById("searchInput");

const filterStatus =
    document.getElementById("filterStatus");

const filterPriority =
    document.getElementById("filterPriority");

const totalTasks =
    document.getElementById("totalTasks");

const completedTasks =
    document.getElementById("completedTasks");

const pendingTasks =
    document.getElementById("pendingTasks");

const highPriorityTasks =
    document.getElementById("highPriorityTasks");

// ===============================
// DISPLAY TASKS
// ===============================

function displayTasks(tasksToDisplay) {

    // Clear existing cards

    taskContainer.innerHTML = "";

    // If there are no tasks

    if (tasksToDisplay.length === 0) {
        const message =
            document.createElement("p");
        message.textContent =
            "No tasks found.";
        taskContainer.appendChild(message);
        return;
    }

    // Create task cards

    tasksToDisplay.forEach(task => {
        const taskCard =
            document.createElement("div");
        taskCard.classList.add("task-card");

        // Add completed class

        if (task.status === "Completed") {
            taskCard.classList.add("completed");
        }

        taskCard.innerHTML = `
            <h3>${task.title}</h3>
            <p>
                ${task.description}
            </p>
            <p>
                <strong>Priority:</strong>
                ${task.priority}
            </p>
            <p>
                <strong>Category:</strong>
                ${task.category}
            </p>
            <p>
                <strong>Due Date:</strong>
                ${task.date}
            </p>
            <p>
                <strong>Status:</strong>
                ${task.status}
            </p>

            <div class="task-actions">
                <button
                    class="complete-btn"
                    data-id="${task.id}">
                    ${task.status === "Completed"
                        ? "Undo"
                        : "Complete"}
                </button>
                <button
                    class="edit-btn"
                    data-id="${task.id}">
                    Edit
                </button>
                <button
                    class="delete-btn"
                    data-id="${task.id}">
                    Delete
                </button>
            </div>
        `;

        taskContainer.appendChild(taskCard);
    });
}

// ===============================
// GET FORM DATA
// ===============================

function getFormData() {
    return {
        title: taskTitle.value.trim(),
        description:
            taskDescription.value.trim(),
        priority:
            taskPriority.value,
        category:
            taskCategory.value,
        date:
            taskDate.value
    };
}

// ===============================
// CLEAR FORM
// ===============================

function clearForm() {

    taskForm.reset();
}

// ===============================
// UPDATE DASHBOARD
// ===============================

function updateDashboard(
    total,
    completed,
    pending,
    highPriority
) {

    totalTasks.textContent = total;

    completedTasks.textContent = completed;

    pendingTasks.textContent = pending;

    highPriorityTasks.textContent =
        highPriority;
}